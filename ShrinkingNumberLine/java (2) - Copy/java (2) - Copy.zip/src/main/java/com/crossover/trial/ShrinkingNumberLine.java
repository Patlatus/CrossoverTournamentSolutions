package com.crossover.trial;

import java.io.IOException;
import java.util.Scanner;

public class ShrinkingNumberLine {
	
    /**
     * Complete the function below.
     */
    static int minimize(int[] point, int k) {
    	int min = point[0];
    	int max = point[0];
    	for ( int i: point ) {
    		if ( i < min )
    			min = i;
    		if ( i > max )
    			max = i;
    	}
    	int avg = ( min + max ) / 2;
    	for ( int i = 0; i < point.length; i++ ) {
    		
    		if ( point[i] < avg )
    			point[i] += k;
    		else
    			if ( point[i] > avg )
        			point[i] -= k;
        		
    	}
    	min = point[0];
    	max = point[0];
    	for ( int i: point ) {
    		if ( i < min )
    			min = i;
    		if ( i > max )
    			max = i;
    	}
    	
        return max - min;
    }

    /**
     * DO NOT MODIFY THIS METHOD!
     */
    public static void main(String[] args) throws IOException {
        Scanner in = new Scanner(System.in);

        int _point_size = Integer.parseInt(in.nextLine().trim());
        int[] _point = new int[_point_size];
        int _point_item;
        for (int _point_i = 0; _point_i < _point_size; _point_i++) {
            _point_item = Integer.parseInt(in.nextLine().trim());
            _point[_point_i] = _point_item;
        }

        int _k = Integer.parseInt(in.nextLine().trim());

        System.out.println(minimize(_point, _k));
    }
}
